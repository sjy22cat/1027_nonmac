from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
m=json.loads((r/"UPLOAD_MANIFEST.json").read_text(encoding="utf-8"))
bad=[n for n,h in m["files"].items() if not (r/n).is_file() or hashlib.sha256((r/n).read_bytes()).hexdigest()!=h]
if bad: raise SystemExit(str(bad))
assert not any("nonmac_test_dw" in n for n in m["files"])
assert not any(n.startswith("tb/") for n in m["files"])
assert not any(n.endswith("/pt.tcl") for n in m["files"])
assert "pt_shell" not in (r/"synopsys/run_flow.py").read_text(encoding="utf-8")
print("PASS upload SHA256:",len(m["files"]),"files; DC only, no PT/testbench or test DW models")
