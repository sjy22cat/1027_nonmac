`timescale 1ns/1ps
// One FP32 element datapath, intended for one PE tile. The controller,
// normalization reduction and scalar statistics are shared by the array.
// Four 32-bit words are reused by lifetime; no full-vector registers here.
module llm_nonmac_tile_fp32 #(
 parameter TILE_ID=0
)(
 input wire clk,
 input wire load, input wire [4:0] load_op,
 input wire [31:0] load_x,load_y,load_gamma,load_beta,
 input wire word_load, input wire [1:0] word_role, input wire [31:0] word_data,
 input wire active,run, input wire [4:0] op_q, input wire [5:0] phase,
 input wire [31:0] stat_q,mean_q,scale_q,epsilon_q,length_fp,
 input wire [31:0] rope_partner, input wire rope_first,
 input wire [31:0] pair_t0,pair_t1,
 output wire [31:0] value,square,arithmetic_result,
 output wire input_error,arithmetic_error
);
 localparam P_CHECK=0,P_BASIC=1,P_RSQRT=2,P_SIG_EXP=3,P_SIG_ADD=4,
 P_SIG_DIV=5,P_ACT_MUL=6,P_GATE=7,P_GELU_SQ=8,P_GELU_CUBE=9,
 P_GELU_COEFF=10,P_GELU_ADD=11,P_GELU_GAIN=12,P_SM_MAX=13,
 P_SM_SUB=14,P_SM_EXP=15,P_SM_SUM=16,P_INV=17,P_SM_MUL=18,
 P_N_SQ=19,P_N_SUM=20,P_N_DIV=21,P_EPS=22,P_N_SQRT=23,
 P_N_MUL=24,P_GAMMA=25,P_BETA=26,P_MEAN_SUM=27,P_MEAN_DIV=28,
 P_CENTER=29,P_ROPE_A=30,P_ROPE_B=31,P_ROPE_COMB=32,
 P_PAIR_A=33,P_PAIR_B=34,P_PAIR_SUB=35,P_PAIR_C=36,P_PAIR_D=37,
 P_PAIR_ADD=38,P_FINISH=39;
 localparam [31:0] ONE=32'h3f800000;
 reg [31:0] x_q,y_q,gamma_q,beta_q;
 reg sign_q;
 wire [31:0] x=x_q,y=y_q;
 wire gelu=(op_q==9)||(op_q==22);
 wire [31:0] arg=gelu?gamma_q:x;
 wire [31:0] partner=rope_partner,cos_v=gamma_q,sin_v=beta_q;
 wire need_y=(op_q<=3)||(op_q==11)||(op_q==19)||(op_q==23)||(op_q==10);
 wire need_g=(op_q==17)||(op_q==18)||(op_q==24)||(op_q==10);
 wire need_b=(op_q==18)||(op_q==24)||(op_q==10);
 function automatic finite(input [31:0] a);
  finite=a[30:23]!=8'hff;
 endfunction
 assign value=x_q;
 assign square=y_q;
 assign arithmetic_result=result;
 assign input_error=active&&(!finite(x_q)||(need_y&&!finite(y_q))||
  (need_g&&!finite(gamma_q))||(need_b&&!finite(beta_q)));
 assign arithmetic_error=run&&!finite(result);
  reg [31:0] aa,ab,ma,mb,da,db,ea,sa,result;
  reg sub;
  wire [31:0] az,mz,dz,ez,sz;
  wire [7:0] ast,mst,dst,est,sst;
  // Each generated instance is physically independent of other element lanes.
  DW_fp_addsub #(23,8,1) u_add(aa,ab,3'b000,sub,az,ast);
  DW_fp_mult #(23,8,1) u_mul(ma,mb,3'b000,mz,mst);
  DW_fp_div #(23,8,1,0) u_div(da,db,3'b000,dz,dst);
  DW_fp_exp #(23,8,1,0) u_exp(ea,ez,est);
  DW_fp_sqrt #(23,8,1) u_sqrt(sa,3'b000,sz,sst);
  always @* begin
   aa=0;ab=0;sub=0;ma=0;mb=0;da=0;db=ONE;ea=0;sa=0;
   if(run)begin
    case(phase)
     P_BASIC:begin
      case(op_q)
       0,1,19:begin aa=x;ab=y;sub=(op_q==1);end
       2,20:begin ma=x;mb=op_q==20?scale_q:y;end
       3:begin da=x;db=y;end
       4:ea=x;
       5,6:sa=x;
       default:begin end
      endcase
     end
     P_RSQRT:begin da=ONE;db=x;end
     P_SIG_EXP:ea={1'b1,arg[30:0]};
     P_SIG_ADD:begin aa=ONE;ab=gamma_q;end
     P_SIG_DIV:begin da=sign_q?gamma_q:ONE;db=beta_q;end
     P_ACT_MUL:begin ma=x;mb=gamma_q;end
     P_GATE:begin ma=x;mb=y;end
     P_GELU_SQ,P_N_SQ:begin ma=x;mb=x;end
     P_GELU_CUBE:begin ma=gamma_q;mb=x;end
     P_GELU_COEFF:begin ma=gamma_q;mb=32'h3d372713;end
     P_GELU_ADD:begin aa=x;ab=gamma_q;end
     P_GELU_GAIN:begin ma=gamma_q;mb=32'h3fcc422a;end
     P_INV:begin da=ONE;db=stat_q;end
     P_N_DIV,P_MEAN_DIV:begin da=stat_q;db=length_fp;end
     P_EPS:begin aa=stat_q;ab=epsilon_q;end
     P_N_SQRT:sa=stat_q;
     P_N_MUL:begin ma=x;mb=stat_q;end
     P_GAMMA:begin ma=x;mb=gamma_q;end
     P_BETA:begin aa=x;ab=beta_q;end
     P_CENTER:begin aa=x;ab=mean_q;sub=1;end
     P_ROPE_A:begin ma=x;mb=cos_v;end
     P_ROPE_B:begin ma=partner;mb=sin_v;end
     P_ROPE_COMB:begin aa=y;ab=gamma_q;sub=rope_first;end
     P_PAIR_A:begin ma=x;mb=gamma_q;end
     P_PAIR_B:begin ma=y;mb=beta_q;end
     P_PAIR_SUB:begin aa=pair_t0;ab=pair_t1;sub=1;end
     P_PAIR_C:begin ma=x;mb=beta_q;end
     P_PAIR_D:begin ma=y;mb=gamma_q;end
     P_PAIR_ADD:begin aa=pair_t1;ab=y;end
     default:begin end
    endcase
   end
  end
  always @* begin
   result=0;
   case(phase)
    P_BASIC:case(op_q)
     0,1,19:result=az;
     2,20:result=mz;
     3:result=dz;
     4:result=ez;
     5,6:result=sz;
     12,25:result=x[31]?0:x;
     default:result=0;
    endcase
    P_SIG_ADD,P_GELU_ADD,P_EPS,P_BETA,P_CENTER,
    P_ROPE_COMB,P_PAIR_SUB,P_PAIR_ADD:result=az;
    P_SIG_EXP:result=ez;
    P_RSQRT,P_SIG_DIV,P_INV,P_N_DIV,P_MEAN_DIV:result=dz;
    P_N_SQRT:result=sz;
    default:result=mz;
   endcase
  end
 always @(posedge clk)begin
  if(load)begin
   x_q<=load_x;
   if(load_op<=3||load_op==10||load_op==11||load_op==19||load_op==23)y_q<=load_y;
   if(load_op==10||load_op==17||load_op==18||load_op==24)gamma_q<=load_gamma;
   if(load_op==10||load_op==18||load_op==24)beta_q<=load_beta;
  end else if(word_load)begin
   case(word_role)
    0:x_q<=word_data;
    1:y_q<=word_data;
    2:gamma_q<=word_data;
    3:beta_q<=word_data;
   endcase
  end else if(run)begin
   case(phase)
    P_BASIC,P_RSQRT,P_ACT_MUL,P_GATE,P_N_MUL,P_GAMMA,P_BETA,P_CENTER,P_ROPE_COMB:x_q<=result;
    P_SIG_EXP:begin gamma_q<=result;sign_q<=arg[31];end
    P_SIG_ADD:beta_q<=result;
    P_SIG_DIV:if(op_q==7)x_q<=result;else gamma_q<=result;
    P_GELU_SQ,P_GELU_CUBE,P_GELU_COEFF,P_GELU_ADD,P_GELU_GAIN:gamma_q<=result;
    P_N_SQ,P_ROPE_A,P_PAIR_D:y_q<=result;
    P_ROPE_B:gamma_q<=result;
    P_PAIR_ADD:x_q<=pair_t0;
    default:begin end
   endcase
  end
 end
endmodule
