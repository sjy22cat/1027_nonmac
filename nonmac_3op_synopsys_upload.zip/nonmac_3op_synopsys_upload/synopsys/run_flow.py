#!/usr/bin/env python3
"""Three fixed engines; each uses one DC session for mapping/STA/area/power."""
import argparse,json,math,os
from pathlib import Path
from flow_helpers import execute,write_config,sha
from dc_reports import clear_power_outputs,finalize_power

ROOT=Path(__file__).resolve().parents[1]
CASES={"rmsnorm":(17,1024,[128,1024]),"rope":(24,128,[128]),"swiglu":(23,1024,[1024])}
MODEL_CYCLES={"rmsnorm":10,"rope":5,"swiglu":9}

def profiles_model(name,lengths,period_ns):
    cycles=MODEL_CYCLES[name]
    return dict(status="SCHEDULE_MODEL_NOT_REMEASURED",operation=name,
        basis="Existing cycle model; 1ns/cycle latency; no functional simulation this run",
        profiles=[dict(n=n,cycles_model=cycles,nominal_ns=cycles*1.0,valid_ns=None,
                       energy_estimation_duration_ns=cycles*period_ns) for n in lengths])

def main():
    ap=argparse.ArgumentParser(__doc__)
    ap.add_argument("--site",default="synopsys/site.json")
    ap.add_argument("--stage",default="all",choices=("dc","sta","power","analyze","all"),
                    help="all/dc: map and analyze in DC; analyze/sta/power: reuse mapped.v, no compile")
    ap.add_argument("--operation",default="all",choices=("all",)+tuple(CASES))
    ap.add_argument("--output",default="results/smic28_dconly")
    args=ap.parse_args();os.chdir(ROOT)
    site=json.loads(Path(args.site).read_text(encoding="utf-8"))
    for p in site["target_db"]+site["extra_link_db"]:
        if not Path(p).is_file():raise FileNotFoundError(p)
    if not isinstance(site["period_ns"],(int,float)) or not math.isfinite(site["period_ns"]) or site["period_ns"]<=0:
        raise ValueError("period_ns must be positive")
    site.setdefault("vectorless_toggle_rate_per_cycle",0.1)
    site.setdefault("vectorless_static_probability",0.5)
    toggle=site["vectorless_toggle_rate_per_cycle"];prob=site["vectorless_static_probability"]
    if not isinstance(toggle,(int,float)) or not math.isfinite(toggle) or toggle<0:raise ValueError("Invalid toggle rate")
    if not isinstance(prob,(int,float)) or not math.isfinite(prob) or not 0<=prob<=1:raise ValueError("Invalid static probability")
    sources=(ROOT/"sources.f").read_text(encoding="utf-8").splitlines()
    for name in (CASES if args.operation=="all" else [args.operation]):
        op,lanes,lengths=CASES[name]
        out=Path(args.output).resolve()/name;out.mkdir(parents=True,exist_ok=True)
        config=dict(site,op=op,lanes=lanes)
        identity=dict(operation=name,op=op,lanes=lanes,site=site,
            power_mode="VECTORLESS_ASSUMED_ACTIVITY",source_sha256={p:sha(ROOT/p) for p in sources})
        manifest=out/"manifest.json"
        if manifest.exists() and json.loads(manifest.read_text(encoding="utf-8"))!=identity:
            raise ValueError("Changed RTL/config: choose another --output")
        manifest.write_text(json.dumps(identity,indent=2)+"\n",encoding="utf-8")
        model=profiles_model(name,lengths,site["period_ns"])
        (out/"profiles_model.json").write_text(json.dumps(model,indent=2)+"\n",encoding="utf-8")
        reuse=args.stage in ("analyze","sta","power")
        if reuse and not (out/"mapped.v").is_file():raise RuntimeError("Run DC mapping first")
        cfg=write_config(config,out)
        env=dict(os.environ,NONMAC_CONFIG_TCL=str(cfg),DC_REUSE_MAPPED="1" if reuse else "0")
        clear_power_outputs(out)
        execute(["dc_shell","-f","synopsys/dc.tcl"],out/("dc_analyze.log" if reuse else "dc.log"),env)
        if not (out/"mapped.v").is_file():raise RuntimeError("Incomplete mapping")
        assumptions=dict(mode="VECTORLESS_ASSUMED_ACTIVITY",toggle_rate_per_cycle=toggle,
            static_probability=prob,clock_toggles_per_cycle=2.0,reset_n_static_probability=1.0,
            profile_scope="One generic engine activity assumption; not runtime-length-specific command power",
            state_correlation="Not characterized; no legal-command activity trace")
        status=finalize_power(out,"profiles_model",model,assumptions)
        print(name,"reports:",out,"; DC power:",status["status"],status["reason"])
    print("No functional simulation performed; latency is a model and power/energy use assumed activity.")

if __name__=="__main__":main()
