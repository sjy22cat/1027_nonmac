from datetime import datetime
from pathlib import Path
import hashlib,json,shutil,tempfile,zipfile
ROOT=Path(__file__).resolve().parents[1]
NAME="nonmac_3op_synopsys_upload"
VERIFY='''from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
m=json.loads((r/"UPLOAD_MANIFEST.json").read_text(encoding="utf-8"))
bad=[n for n,h in m["files"].items() if not (r/n).is_file() or hashlib.sha256((r/n).read_bytes()).hexdigest()!=h]
if bad: raise SystemExit(str(bad))
assert not any("nonmac_test_dw" in n for n in m["files"])
assert not any(n.startswith("tb/") for n in m["files"])
assert not any(n.endswith("/pt.tcl") for n in m["files"])
assert "pt_shell" not in (r/"synopsys/run_flow.py").read_text(encoding="utf-8")
print("PASS upload SHA256:",len(m["files"]),"files; DC only, no PT/testbench or test DW models")
'''
def main():
    output=ROOT/"upload";output.mkdir(exist_ok=True)
    names=["README.md","SOURCE_SNAPSHOT.json","sources.f"]
    names+=(ROOT/"sources.f").read_text(encoding="utf-8").splitlines()
    names += ["synopsys/"+n for n in ("site.example.json","common.tcl","constraints.tcl","dc.tcl","dc_analysis.tcl","dc_reports.py",
        "flow_helpers.py","run_flow.py","collect_candidate.py","PROMPT_SYNOPSYS.md","decoder_nonmac.template.json","build_upload.py")]
    with tempfile.TemporaryDirectory(prefix="nonmac3-bundle-") as td:
        folder=Path(td)/NAME;folder.mkdir()
        for n in names:
            target=folder/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/n,target)
        (folder/"verify_upload.py").write_text(VERIFY,encoding="utf-8")
        names += ["verify_upload.py","UPLOAD_FILE_LIST.txt"]
        (folder/"UPLOAD_FILE_LIST.txt").write_text("\n".join(sorted(names+["UPLOAD_MANIFEST.json"]))+"\n",encoding="utf-8")
        hashes={n:hashlib.sha256((folder/n).read_bytes()).hexdigest() for n in names}
        (folder/"UPLOAD_MANIFEST.json").write_text(json.dumps(dict(files=hashes),indent=2)+"\n",encoding="utf-8")
        zpath=Path(td)/(NAME+".zip")
        with zipfile.ZipFile(zpath,"w",zipfile.ZIP_DEFLATED) as z:
            for n in sorted(names+["UPLOAD_MANIFEST.json"]): z.write(folder/n,NAME+"/"+n)
        with zipfile.ZipFile(zpath) as z:
            assert z.testzip() is None
            for n,h in hashes.items(): assert hashlib.sha256(z.read(NAME+"/"+n)).hexdigest()==h
        previous=[output/NAME,output/(NAME+".zip"),output/"syn_nonmac.md"]
        if any(p.exists() for p in previous):
            history=ROOT.parent/"_history"/("nonmac3_upload_"+datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
            assert history.resolve().is_relative_to(ROOT.parent.resolve())
            history.mkdir(parents=True)
            for p in previous:
                assert p.resolve().parent==output.resolve()
                assert (history/p.name).resolve().is_relative_to(history.resolve())
                if p.exists(): shutil.move(str(p),str(history/p.name))
        shutil.copytree(folder,output/NAME);shutil.copyfile(zpath,output/(NAME+".zip"))
        shutil.copyfile(ROOT/"synopsys/PROMPT_SYNOPSYS.md",output/"syn_nonmac.md")
    print(output/(NAME+".zip"));print("PASS ZIP/expanded SHA256",len(hashes),"files")
if __name__=="__main__":main()
