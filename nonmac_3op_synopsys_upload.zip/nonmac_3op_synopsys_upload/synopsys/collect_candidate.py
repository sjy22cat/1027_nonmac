"""Collect mapped area and explicitly modeled latency/vectorless energy."""
import argparse,csv,json,math
from pathlib import Path
from flow_helpers import sha
from dc_reports import verify_dc_power_files

def attributes(path):
    if not path.is_file():return {}
    with path.open(encoding="utf-8") as stream:
        return {r["attribute"]:r["value_in_tool_units"] for r in csv.DictReader(stream,delimiter="\t")}

def number(values,name):
    try:value=float(values[name])
    except (KeyError,ValueError):return None
    return value if math.isfinite(value) and value>=0 else None

def collect_operation(root):
    if not (root/"manifest.json").is_file():return dict(status="PENDING",reason="No engine manifest")
    manifest=json.loads((root/"manifest.json").read_text(encoding="utf-8"));site=manifest["site"]
    if manifest.get("power_mode")!="VECTORLESS_ASSUMED_ACTIVITY":raise ValueError("Not a no-simulation result: "+str(root))
    model=json.loads((root/"profiles_model.json").read_text(encoding="utf-8"))
    netlist_hash=sha(root/"mapped.v") if (root/"mapped.v").is_file() else None
    result=dict(status="RAW_VECTORLESS_ESTIMATE_UNAUDITED",hardware_lanes=manifest["lanes"],
        netlist_sha256=netlist_hash,functional_simulation="SKIPPED_PER_USER_REQUEST",
        area_um2=None,power_w=None,idle_dynamic_w=None,power_assumptions=None,
        profile_power_is_shared_assumption=True,
        profiles=[dict(p,energy_estimate_pj=None,dynamic_pj=None) for p in model["profiles"]],
        reports=sorted(p.name for p in root.glob("*.rpt")))
    area=number(attributes(root/"dc_area_raw.tsv"),"area")
    if area is not None:result["area_um2"]=area*site["library_area_unit_um2"]
    identity_path=root/"power_identity.json";identity={}
    if identity_path.is_file():
        identity=json.loads(identity_path.read_text(encoding="utf-8"))
        if identity["netlist_sha256"]!=netlist_hash or identity["profiles_model"]!=model:
            raise ValueError("Power/model uses different netlist or profiles: "+str(root))
        if identity["assumptions"]["mode"]!="VECTORLESS_ASSUMED_ACTIVITY":raise ValueError("Wrong power mode")
        result["power_assumptions"]=identity["assumptions"]
        verify_dc_power_files(root,identity)
    result["analysis_tool"]=identity.get("analysis_tool")
    result["power_status"]=identity.get("power_status")
    raw=root/"power_raw.tsv"
    if raw.is_file():
        if result["power_assumptions"] is None:raise ValueError("Missing vectorless power identity")
        values=attributes(raw);area=number(values,"area")
        if area is not None:result["area_um2"]=area*site["library_area_unit_um2"]
        power={k:number(values,k) for k in ("internal_power","switching_power","leakage_power")}
        if all(v is not None for v in power.values()):
            scale=identity.get("power_unit_w",site.get("tool_power_unit_w",1.0));internal=power["internal_power"]*scale
            switching=power["switching_power"]*scale;leakage=power["leakage_power"]*scale
            result["power_w"]=dict(internal=internal,switching=switching,dynamic=internal+switching,
                                   leakage=leakage,total=internal+switching+leakage)
            for profile in result["profiles"]:
                ns=profile["energy_estimation_duration_ns"]
                profile["energy_estimate_pj"]=dict(dynamic=(internal+switching)*ns*1000,
                    leakage=leakage*ns*1000,total=(internal+switching+leakage)*ns*1000,
                    modeled_duration_ns=ns,valid_total_pj=None,
                    basis="GENERIC_ENGINE_VECTORLESS_POWER_TIMES_MODELED_DURATION_NOT_LENGTH_SPECIFIC_COMMAND_ENERGY")
    return result

def main():
    ap=argparse.ArgumentParser(__doc__);ap.add_argument("results",type=Path);args=ap.parse_args()
    report=dict(status="RAW_VECTORLESS_ESTIMATE_NOT_FOR_MEASURED_IMPORT",
                operations={name:collect_operation(args.results/name) for name in ("rmsnorm","rope","swiglu")})
    out=args.results/"nonmac_ppa.raw_candidate.json"
    out.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    print(out,"; latency/energy are estimates; no functional or command-activity simulation performed.")

if __name__=="__main__":main()
