source synopsys/common.tcl
set_app_var target_library $target_db
set_app_var synthetic_library [list dw_foundation.sldb]
set_app_var link_library [concat [list *] $target_db $extra_link_db [list dw_foundation.sldb]]
if {$::env(DC_REUSE_MAPPED)=="1"} {
    read_verilog [file join $run_dir mapped.v]
    current_design nonmac_vector_eval
    link
    source synopsys/constraints.tcl
} else {
    define_design_lib WORK -path [file join $run_dir work]
    set fd [open sources.f r]
    set rtl [split [string trim [read $fd]] \n]
    close $fd
    analyze -format sverilog $rtl
    elaborate nonmac_vector_eval -parameters "OP=$op,LANES=$lanes"
    current_design nonmac_vector_eval
    link
    uniquify
    source synopsys/constraints.tcl
    save_report dc_check_before.rpt {check_design}
    # Single moderate-effort mapping pass. No repeated timing closure.
    compile -map_effort medium
    write -format verilog -hierarchy -output [file join $run_dir mapped.v]
    write_sdc [file join $run_dir mapped.sdc]
}
source synopsys/dc_analysis.tcl
exit
