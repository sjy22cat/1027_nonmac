# 三个非 MAC 算子：仅综合的简化评估

按用户要求，本轮不做功能仿真。直接综合已有RTL，获取映射面积 **µm²**、实际STA状态、模型延迟 **ns**和基于假设活动率的能耗 **pJ**。不调用VCS，不要求DW仿真模型，不生成VCD/SAIF。
原SIM-1023 RTL不改，快照来源与SHA256见`SOURCE_SNAPSHOT.json`。

| 物理引擎 | `nonmac_vector_eval` 参数 | 长度 | 1ns/周期建模延迟 |
|---|---|---|---:|
| RMSNorm | OP=17、LANES=1024 | 128、1024 | 各10ns |
| RoPE | OP=24、LANES=128 | 128 | 5ns |
| SwiGLU | OP=23、LANES=1024 | 1024 | 9ns |

RMSNorm两个长度共用同一网表，面积只计一次；不能缩小为128-lane硬件。SwiGLU包含真实gate/up配对及preload；3072维FFN对应三次1024元素命令。RoPE使用预计算cos/sin。本轮不重新验证周期，沿用既有模型；即使1ns STA失败，仍按10/5/9ns建模，STA结果另列，`valid_ns`留空。
所有内部乘加均属于这些非MAC功能，不做Attention的QK/PV扣除。范围含引擎/适配器/局部寄存器，不含外部GSRAM/PHY、格式转换和sin/cos表生成。

## 只上传及执行这些

上传 [upload/nonmac_3op_synopsys_upload.zip](upload/nonmac_3op_synopsys_upload.zip)，解压后进入同名目录，将 [upload/syn_nonmac.md](upload/syn_nonmac.md) 发给服务器Codex（包内同一份为`synopsys/PROMPT_SYNOPSYS.md`）。

```bash
python3 verify_upload.py
cp synopsys/site.example.json synopsys/site.json
# 填实际SMIC .db路径，核实单位和活动率假设
python3 synopsys/run_flow.py --stage all
python3 synopsys/collect_candidate.py results/smic28_dconly
```

总共3次DC、0次PT。每个引擎单次`compile -map_effort medium`，同一DC会话先完成基本STA，再分析面积与Power Compiler无波形功耗。STA是分析方法，PT是工具；本包不启动独立PT或PrimePower。保留各10条setup/hold路径与约束/QoR摘要，不输出海量逐项违例清单。不再测四个命令窗口/三个空闲窗口，不扫描种子/长度，不搜索Fmax或反复闭合时序，不写/重载全局DDC。保存映射网表/SDC及必要汇总报告。可用`--operation rmsnorm/rope/swiglu`分开执行；`--stage all`或`--stage dc`均为一次映射加分析；`--stage analyze --output <已有结果根目录>`仅在DC内读网表重分析，不重新compile。旧参数`--stage sta/power`也转为同样的DC重分析。
新结果目录为`results/smic28_dconly`；旧活动测量和上传包归档保留。已有同源同约束产物可复用，变更源码/库/参数/假设需换输出目录，不能混用。

库角为SMIC28nm SCC28NHKCP_HSC35P140_RVT_V0p2，RVT/SS/0.9V/125°C。1ns及接口约束见`constraints.tcl`。服务器需SMIC库和DW综合库/许可，不需DW仿真模型。本包不含测试台、授权库或行为替代DW模型。
脚本尚未在本地新思环境执行，服务器应依实际版本help/man修正并留diff。中等强度映射不是最优PPA保证；保留完整链接、无黑盒/未映射引用以及单位检查。

## 能耗是估计值

DC/Power Compiler采用明确的vectorless假设：非时钟/复位输入每周期0.1次翻转、静态1概率0.5；时钟每周期2次翻转，rst_n恒1。可在`site.json`修改，需确认`set_switching_activity -period`语法和单位。FSM阶段及长度相关性没有表征。
若DC功耗命令或许可缺失，保留面积/时序结果，功耗和能耗写null/PENDING，不回退PT。收集器逐项读取`report_power`中明确的动态/漏电单位并统一成W；不能解析的格式保留报告、标PENDING，人工核对后再填值。
每个引擎仅一份通用活动功率：`E_estimate_pJ=P_vectorless_W*模型时长ns*1000`，动态和漏电分开。1ns时默认模型时长分别10/5/9ns；若改变目标时钟，能耗估算使用该功率频点对应的模型时长，主表1ns/周期建模延迟仍单列。
RMSNorm128/1024共享同一引擎功率且周期相同，粗估能耗会相同；不能冒充长度分别表征的命令能耗。空闲动态功耗未测，保持null。功耗依赖假设，即使STA通过也不升级为实际命令活动测量或MEASURED。

## 返回数据

`collect_candidate.py`仅收集RAW候选：四个profile的模型延迟/估计pJ、三个引擎的面积/功耗、活动假设、网表hash及原始报告。未知项保留null，功能状态`SKIPPED_PER_USER_REQUEST`。
可以参考`decoder_nonmac.template.json`整理reviewed JSON。本轮结果用于估算，不能直接通过既有严格实测导入器；不放宽导入器、不修改SIM-1023、Excel或历史校准。以后有匹配活动数据时再补真实命令功耗与空闲数据。
此前本地测试和日志仍保留在仓库，本轮不重跑、不要求服务器验证，也不放入上传包。
